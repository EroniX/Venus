import { Component, OnInit, Input } from '@angular/core';


@Component({
    selector: 'blog-about',
    templateUrl: '/app/components/about/about.component.html'
})

export class AboutComponent {

}