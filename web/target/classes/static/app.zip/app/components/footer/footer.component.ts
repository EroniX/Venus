import { Component, OnInit, Input } from '@angular/core';
@Component({
    selector: 'blog-footer',
    templateUrl: '/app/components/footer/footer.component.html'
})
export class FooterComponent {}